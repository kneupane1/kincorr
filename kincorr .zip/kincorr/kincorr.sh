#!/bin/bash
./kincorr data/test.root "histogram" data/ideal.root "histogram" 50
