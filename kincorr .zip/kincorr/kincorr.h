#ifndef __KINCORR_H__
#define __KINCORR_H__

#include <THnSparse.h>
#include <TH1D.h>
#include <TH2D.h>
#include <TH3D.h>
#include <string>

//constants
extern double ELECTRON_MASS;
extern double PROTON_MASS;

//control parameters
extern bool GRADIENT_PRINT_PROGRESS;
extern double BEAM_ENERGY;
extern double TARGET_MASS;
extern int W_NBINS;
extern double W_LOW;
extern double W_HIGH;

//Simple single-threaded gradient descent algorithm.  Returns number
//of steps required and places final results in result.  Assumes
//result has already had memory allocated.
//
//scale needs to be chosen carefully for each function f.  Too large
//and the algorithm never converges.  Too small and it takes way too
//long to converge.  For many problems the best guess is scale<1.
//
//For some problems, prec and diffstep need to be tweaked as well.
int gradient_descent(double (*f)(double*),
                     int ndims,
                     double* init,
                     double* result,
                     double scale=1,
                     long maxsteps=10000,
                     double diffstep=1e-9,
                     double prec=1e-5);

double hist_euclidean_dist2(TH1D* a, TH1D* b);
int init_energy_theta_params(int degree,double*& result);

//Transform (energy,theta) and project into W
TH1D* kincorr_energy_theta_to_W(TH2D* energy_theta,
                                int nparams,
                                double* params,
                                int Wnbins=W_NBINS,
                                double Wlow=W_LOW,
                                double Whigh=W_HIGH,
                                std::string name="kcorrWhist",
                                std::string title="kcorrWhist");
#endif
