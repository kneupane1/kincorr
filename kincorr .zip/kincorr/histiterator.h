#ifndef __THITERATOR__
#define __THITERATOR__

#include <iterator>
#include <THnSparse.h>
#include <TH1D.h>
#include <TH2D.h>
#include <TH3D.h>

/*
  Header-only library of input iterators for less painful use of ROOT
  histograms.

  Usage is straightfoward: To iterate over a TH1D called "hist", use

  for(TH1Diterator i(&hist); i != i.end(); ++i) {
    double x = i.x;//bin center
    double val = i.val;//count
    double err=0;//error bar
    if(i.geterr) err=i.err;
    //do stuff with the x, val, err values
  }

  The TH2Diterator and TH3Diterator types work the same, except there
  are also i.y and i.z data members accessible.

  For THnSparseDiterator, there are only i.x, i.val, and i.err, but
  i.x is a pointer to an array with i.ndims elements representing the
  bin center in ndims dimensional space.

  NOTE: I tried at first to make this integrate seemlessly with the
  C++11 features so that you could do something like

  "for(auto i : myhist) {...}",

  but it wasn't worth the hassle at the time.  It might be worth it
  for someone else though.  I also did not bother extending this to
  support modifying the histogram as an output iterator, but it would
  be straightforward to do so.
 */

class TH1Diterator {
public:
  long ix;
  int nbins;
  double x;
  double val;
  double err;
  double geterr;
  TH1D* h;
  //Gets information from histogram for current bin
  void gethist() {
    if(ix != nbins) {
      x=h->GetBinCenter(ix+1);
      val=h->GetBinContent(ix+1);
      if(geterr) err=h->GetBinError(ix+1);
    }
  }
  TH1Diterator(TH1D* hist, int i=0) : h(hist) , ix(i){
    nbins=h->GetNbinsX();
    geterr = (h->GetSumw2N() != 0);
    gethist();
  }

  TH1Diterator& operator++() {++ix; gethist(); return *this;}
  TH1Diterator& operator++(int j) {ix++; gethist(); return *this;}
  bool operator!=(const TH1Diterator& i) const {return (ix != i.ix);}
  TH1Diterator begin() {
    return TH1Diterator(h);
  }
  TH1Diterator end() {
    return TH1Diterator(h, nbins);
  }
};

class TH2Diterator {
public:
  long i;
  long glob;
  int nbins;
  long ix;
  int nbinsx;
  long iy;
  int nbinsy;
  double x;
  double y;
  double val;
  double err;
  double geterr;
  TH2D* h;
  //Gets information from histogram for current bin
  void gethist() {
    if(i != nbins) {
      ix = i%nbinsx + 1;
      iy = i/nbinsx + 1;
      x=h->GetXaxis()->GetBinCenter(ix);
      y=h->GetYaxis()->GetBinCenter(iy);
      glob=h->GetBin(ix,iy);
      val=h->GetBinContent(glob);
      if(geterr) err=h->GetBinError(glob);
    }
  }
  TH2Diterator(TH2D* hist, int i=0) : h(hist), i(i) {
    nbinsx=h->GetNbinsX();
    nbinsy=h->GetNbinsY();
    nbins=nbinsx*nbinsy;
    geterr = (h->GetSumw2N() != 0);
    gethist();
  }

  TH2Diterator& operator++() {++i; gethist(); return *this;}
  TH2Diterator& operator++(int j) {i++; gethist(); return *this;}
  bool operator!=(const TH2Diterator& it) const {return (i != it.i);}
  TH2Diterator begin() {
    return TH2Diterator(h);
  }
  TH2Diterator end() {
    return TH2Diterator(h, nbins);
  }
};

class TH3Diterator {
public:
  long i;
  long glob;
  int nbins;
  long ix;
  int nbinsx;
  long iy;
  int nbinsy;
  long iz;
  int nbinsz;
  double x;
  double y;
  double z;
  double val;
  double err;
  double geterr;
  TH3D* h;
  //Gets information from histogram for current bin
  void gethist() {
    if(i != nbins) {
      ix = i%nbinsx + 1;
      iy = (i/nbinsx)%nbinsy + 1;
      iz = i/(nbinsx*nbinsy) + 1;
      x=h->GetXaxis()->GetBinCenter(ix);
      y=h->GetYaxis()->GetBinCenter(iy);
      z=h->GetZaxis()->GetBinCenter(iz);
      glob=h->GetBin(ix,iy,iz);
      val=h->GetBinContent(glob);
      if(geterr) err=h->GetBinError(glob);
    }
  }
  TH3Diterator(TH3D* hist, int i=0) : h(hist), i(i) {
    nbinsx=h->GetNbinsX();
    nbinsy=h->GetNbinsY();
    nbinsz=h->GetNbinsZ();
    nbins=nbinsx*nbinsy*nbinsz;
    geterr = (h->GetSumw2N() != 0);
    gethist();
  }

  TH3Diterator& operator++() {++i; gethist(); return *this;}
  TH3Diterator& operator++(int j) {i++; gethist(); return *this;}
  bool operator!=(const TH3Diterator& it) const {return (i != it.i);}
  TH3Diterator begin() {
    return TH3Diterator(h);
  }
  TH3Diterator end() {
    return TH3Diterator(h, nbins);
  }
};

class THnSparseDiterator {
public:
  long i;
  int ndims;
  int nbins;
  double *x;
  double val;
  double err;
  double geterr;
  THnSparseD* h;
  //Gets information from histogram for current bin
  void gethist() {
    if(i != nbins) {
      val=h->GetBinContent(i);
      if(geterr) err=h->GetBinError2(i);
      int* indices = new int[ndims];
      h->GetBinContent(i,indices);
      for(int j = 0; j < ndims; ++j) {
        TAxis* axis = h->GetAxis(j);
        x[j] = axis->GetBinCenter(indices[j]);
      }
      delete[] indices;
    }
  }
  THnSparseDiterator(THnSparseD* hist, int i=0) : h(hist), i(i) {
    geterr = h->GetCalculateErrors();
    ndims=h->GetNdimensions();
    x = new double[ndims];
    nbins=h->GetNbins();
    gethist();
  }
  ~THnSparseDiterator() {
    delete[] x;
  }

  THnSparseDiterator& operator++() {++i; gethist(); return *this;}
  THnSparseDiterator& operator++(int j) {i++; gethist(); return *this;}
  bool operator!=(const THnSparseDiterator& it) const {return (i != it.i);}
  THnSparseDiterator begin() {
    return THnSparseDiterator(h);
  }
  THnSparseDiterator end() {
    return THnSparseDiterator(h, nbins);
  }
};

#endif
