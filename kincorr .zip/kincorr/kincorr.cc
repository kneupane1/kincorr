#include <iostream>
#include "histiterator.h"
#include <string>
#include <TMath.h>
#include <TH1D.h>
#include <TH2D.h>
#include <TH3D.h>
#include <THnSparse.h>

//Constants
double ELECTRON_MASS=0.000510998918;
double PROTON_MASS=0.938272029;

//Control parameters
bool GRADIENT_PRINT_PROGRESS=false;
int W_NBINS=500;
double W_LOW=0.0;
double W_HIGH=4.5;
double BEAM_ENERGY=10.6;
double TARGET_MASS=PROTON_MASS;

//utilities for gradient descent
double euclidean_dist2(int n, double* x, double* y) {
  double result=0;
  for(int i = 0; i < n; ++i) {
    const double diff=x[i]-y[i];
    result += diff*diff;
  }
  return result;
}
double euclidean_dist(int n, double* x, double* y) {
  return TMath::Sqrt(euclidean_dist2(n,x,y));
}

//Simple single-threaded gradient descent algorithm.  Returns number
//of steps required and places final results in result.  Assumes
//result has already had memory allocated.
//
//scale needs to be chosen carefully for each function f.  Too large
//and the algorithm never converges.  Too small and it takes way too
//long to converge.  For many problems the best guess is scale<1.
//
//For some problems, prec and diffstep need to be tweaked as well.
int gradient_descent(double (*f)(double*),
                     int ndims,
                     double* init,
                     double* result,
                     double scale,
                     long maxsteps,
                     double diffstep,
                     double prec) {
  double* last = new double[ndims];
  double* tmp = new double[ndims];
  double* gradient = new double[ndims];
  for(int i = 0; i < ndims; ++i) {
    last[i] = result[i] = init[i];
  }
  for(int i = 0; i < maxsteps; ++i) {
    double diff = euclidean_dist(ndims,result,last);
    if((i != 0) && (diff < prec)) {
      return i;
    }
    //update last value
    for(int j = 0; j < ndims; ++j) {
      last[j] = result[j];
    }
    //compute gradient
    for(int k = 0; k < ndims; ++k) {
      tmp[k] = result[k];
    }
    for(int j = 0; j < ndims; ++j) {
      tmp[j] += diffstep;
      gradient[j] = (f(tmp)-f(result))/diffstep;
      tmp[j] = result[j];
    }
    if(GRADIENT_PRINT_PROGRESS) {
      std::cout << "Gradient=(";
      for(int j = 0; j < ndims; ++j) {
        std::cout << gradient[j];
        if(j == (ndims-1)) std::cout << ")" << std::endl;
        else std::cout << ",";
      }
    }
    //Subtract scaled gradient
    for(int j = 0; j < ndims; ++j) {
      result[j] -= scale*gradient[j];
    }
  }
  delete[] last;
  delete[] tmp;
  delete[] gradient;
  return maxsteps;
}

//Momentum to W function.

double momentum_to_W(double* momentum) {
  double result=0;
  double tmp=0;
  for(int i = 0; i < 3; ++i) result+=momentum[i]*momentum[i];
  double Eprime = TMath::Sqrt(ELECTRON_MASS*ELECTRON_MASS+result);
  result=BEAM_ENERGY-Eprime;
  result*=result;
  for(int i = 0; i < 3; ++i) {
    if(i == 2) tmp=BEAM_ENERGY-momentum[i];
    else tmp=-momentum[i];
    result-=tmp*tmp;
  }
  return TMath::Sqrt(result);
}

double energy_theta_to_W(double energy, double theta) {
  const double thetarad = M_PI*theta/180.0;
  const double costheta = cos(thetarad);
  const double momentum =
    TMath::Sqrt(energy*energy-ELECTRON_MASS*ELECTRON_MASS);
  return TMath::Sqrt(2*ELECTRON_MASS*ELECTRON_MASS
                     + TARGET_MASS*TARGET_MASS
                     + 2*(BEAM_ENERGY-energy)*TARGET_MASS
                     + 2*BEAM_ENERGY*(momentum*costheta-energy));
}

TH1D* emom_hist_to_W_hist(TH3D* h,
                          int Wnbins=40,
                          double Wlow=0.0,
                          double Whigh=2.0,
                          std::string name="hist",
                          std::string title="hist") {
  TH1D* result = new TH1D(name.c_str(),title.c_str(),
                          Wnbins,Wlow,Whigh);
  for(TH3Diterator i(h); i != i.end(); ++i) {
    double p[3] = {i.x, i.y, i.z};
    double W = momentum_to_W(p);
    result->Fill(W,i.val);
  }
  return result;
}

TH1D* energy_theta_hist_to_W_hist(TH2D* h,
                                  int Wnbins=W_NBINS,
                                  double Wlow=W_LOW,
                                  double Whigh=W_HIGH,
                                  std::string name="hist",
                                  std::string title="hist") {
  TH1D* result = new TH1D(name.c_str(),title.c_str(),
                          Wnbins,Wlow,Whigh);
  for(TH2Diterator i(h); i != i.end(); ++i) {
    double energy = i.x;
    double theta = i.y;
    double W = energy_theta_to_W(energy,theta);
    //safety check for real W
    if(W == W)
      result->Fill(W,i.val);
  }
  return result;
}

//2-D polynomial function
//
//Takes array of length 2 as xs and returns polynomial function of x in
//array of length 2 result.
void polynomial2D(double* xs, int nparams, double* params,
                  double* result) {
  result[0]=result[1]=0;
  int xparams_start=0;
  int xparams_end=nparams/2-1;
  int yparams_start=nparams/2;
  int yparams_end=nparams-1;
  int degree=TMath::Floor(TMath::Sqrt(((double) nparams)/2.0))-1;
  const double x = xs[0];
  const double y = xs[1];
  //Calculate new x
  for(int i = xparams_start; i < xparams_end; ++i) {
    double p=params[i];
    int xdegree=i/(degree+1);
    int ydegree=i%(degree+1);
    result[0]+=p*TMath::Power(x,xdegree)*TMath::Power(y,ydegree);
  }
  //Calculate new y
  for(int i = yparams_start; i < yparams_end; ++i) {
    double p=params[i];
    int xdegree=i/(degree+1);
    int ydegree=i%(degree+1);
    result[1]+=p*TMath::Power(x,xdegree)*TMath::Power(y,ydegree);
  }
  return;
}

//Initializes energy and theta parameters for 2-D polynomial which
//does not modify energy and theta (identity mapping).  Convenient for
//making small changes to identity mapping since organizing the
//polynomial terms is easy to mess up on the fly.
//
//Returns total number of parameters initialized.
int init_energy_theta_params(int degree,double*& result) {
  int nterms = (degree+1)*(degree+1);
  result = new double[2*nterms];
  for(int i = 0; i < nterms; ++i) {
    int j = i+nterms;
    //energy parameters
    if(i == (degree+1)) result[i]=1.0;
    else result[i]=0.0;
    //theta parameters
    if(i == 1) result[j]=1.0;
    else result[j]=0.0;
  }
  return 2*nterms;
}

//Squared norm for 1-D histograms.  Assumes identical binning.
double hist_euclidean_dist2(TH1D* a, TH1D* b) {
  TH1Diterator i(a);
  TH1Diterator j(b);
  double result = 0;
  //Shouldn't need the extra j check, but included for safety.
  for(; i != i.end() && j != j.end(); (++i, ++j)) {
    const double diff = i.val - j.val;
    result += diff*diff;
  }
  return result;
}

//Kinematic corrections for (energy,theta) transformed into W
TH1D* kincorr_energy_theta_to_W(TH2D* energy_theta,
                                int nparams,
                                double* params,
                                int Wnbins,
                                double Wlow,
                                double Whigh,
                                std::string name,
                                std::string title) {
  TH1D* result = new TH1D(name.c_str(),title.c_str(),
                          Wnbins,Wlow,Whigh);
  TH2Diterator i(energy_theta);
  for(; i != i.end(); ++i) {
    double energy_theta[2] = {i.x, i.y};
    double new_energy_theta[2];
    polynomial2D(energy_theta,
                 nparams,
                 params,
                 new_energy_theta);
    double W = energy_theta_to_W(new_energy_theta[0],
                                 new_energy_theta[1]);
    //safety check for real W
    if(W == W)
      result->Fill(W,i.val);
  }
  double integral = result->Integral();
  if(integral != 0)
    result->Scale(1.0/integral);
  return result;
}
