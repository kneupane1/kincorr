#include "histiterator.h"
#include <iostream>
#include <TFile.h>
#include <TH1D.h>
#include <TH2D.h>
#include "kincorr.h"
#include <cstdlib> //for atoi
/*
  Example of using gradient descent to calculate kinematic corrections
  for energy-theta.
*/

//parameters for kincorr_diff2.  Set energy_theta to input (energy,
//theta) histogram needing kinematic corrections.  Set ideal_W to the
//ideal W histogram being fitted against.  If 3-D momentum is desired
//in the future, just create a similar variable and a new/modified
//function as inputs to the gradient descent algorithm.
TH2D* energy_theta;
TH1D* ideal_W;
int kincorr_nparams; //number of parameters for kinematic corrections

//function to be minimized via gradient descent
double kincorr_diff2(double* params) {
  TH1D* W = kincorr_energy_theta_to_W(energy_theta,
                                      kincorr_nparams,
                                      params);
  double result = hist_euclidean_dist2(W,ideal_W);
  delete W;
  return result;
}

int main(int argc, char** argv) {
  //input arguments are
  //
  //* experiment source file
  //* experiment histogram name
  //* simulation source file
  //* simiulation histogram name
  //* maximum iterations
  if(argc != 6) {
    std::cerr << "Usage: kincorr <expfile.root> <expname> <simfile.root> <simname> <maximum_iterations>"
              << std::endl;
    return 1;
  }
  std::string expfilepath(argv[1]);
  std::string expname(argv[2]);
  std::string simfilepath(argv[3]);
  std::string simname(argv[4]);
  int maxiter = atoi(argv[5]);

  //set control parameters
  //
  //some of these were already set, but I'm putting them here too for
  //convenience.

  //Value for CLAS12 data
  //BEAM_ENERGY=10.6;
  //Test value for E1E
  BEAM_ENERGY=2.039;
  TARGET_MASS=PROTON_MASS;//proton
  W_NBINS=500;
  W_LOW=0.0;
  W_HIGH=4.5;

  //load data
  TFile expfile(expfilepath.c_str(),"READ");
  energy_theta = (TH2D*) expfile.Get(expname.c_str());
  TFile simfile(simfilepath.c_str(),"READ");
  ideal_W = (TH1D*) simfile.Get(simname.c_str());

  //normalize ideal_W
  ideal_W->Scale(1.0/ideal_W->Integral());

  //gradient descent
  GRADIENT_PRINT_PROGRESS=true;
  int degree=1;
  double* params;
  kincorr_nparams=init_energy_theta_params(degree,params);

  //Introducing error just to see how the gradient descent handles it:
  params[0]=0.1;

  double result[kincorr_nparams];

  std::cout << "Starting gradient descent for "
            << maxiter << " maximum iterations..."
            << std::endl;

  gradient_descent(kincorr_diff2,
                   kincorr_nparams,
                   params,
                   result,
                   1e-3,
                   maxiter,
                   1e-1,
                   1e-8);
  std::cout << "Result parameters are:" << std::endl;
  for(int i = 0; i < kincorr_nparams; ++i) {
    std::cout << result[i] << std::endl;
  }
  expfile.Close();
  simfile.Close();
}
